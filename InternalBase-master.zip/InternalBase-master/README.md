# Internal-Base
A full roblox internal base -- Everything you need for your own internal

## This includes:
-> Injector (A fork of https://github.com/Deni210/Roblox-MMap-Injector)
-> Module (15% Unc --> Filesystem Environment taken from @goodbytecode)
-> Executor Ui (example)



## How to Update?
Update files are located in `Update\Offsets.hpp` and `Update\Protection.hpp`.
Get Latest offsets, Shuffles and Encryptions at discord.gg/getcloudy

### ON 40 STARS ILL ADD A DUMPER SRC TO IT ASWELL

## Is that cloudy's source?
Nope! This Module and Injector is **DETECTED** By Yara-Ruleset and Roblox detections and wont be used by Cloudy.

# IF YOU USE THIS MODULE...
**please credit @goodbytecode(1303083805447426080). He originally made the Injector and the Environment (UNC).**
