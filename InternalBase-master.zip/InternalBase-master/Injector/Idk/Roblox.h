#pragma once

class instance_t final
{


public:

	uint64_t self;

	std::string name();

};