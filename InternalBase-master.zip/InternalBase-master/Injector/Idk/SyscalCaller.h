#pragma once
#include <Windows.h>
extern "C" DWORD64 CallSyscall(WORD syscall,...);