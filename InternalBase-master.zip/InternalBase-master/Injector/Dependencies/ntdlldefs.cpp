#include "ntdlldefs.h"
HMODULE NTDLL = NULL;